setwd("C:\\Users\\Kaviya\\Desktop\\IT24102068")

baking_time <- rnorm(25, mean = 45, sd = 2)

print(baking_time)

t.test(baking_time, mu = 46, alternative = "less")

