setwd("C:/Users/it24102068/Desktop/IT24102068")

laptop_data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

attach(laptop_data)

pop_mean <- mean(Weight.kg.)

pop_sd <- sd(Weight.kg.)

print(paste("Population Mean :", pop_mean))

print(paste("Population Standard Deviation :", pop_sd))

samples <- c()
for (i in 1:25) {
  s <- sample(Weight.kg., size = 6, replace = TRUE)
  samples <- cbind(samples, s)
}
sample_means <- apply(samples, 2, mean)

sample_sds <- apply(samples, 2, sd)

print(sample_means)

print(sample_sds)

mean_of_sample_means <- mean(sample_means)

sd_of_sample_means <- sd(sample_means)

print(paste("Mean of the Sample Means :", mean_of_sample_means))
print(paste("Standard Deviation of the Sample Means :", sd_of_sample_means))

theoretical_se <- pop_sd / sqrt(6)

print(paste("The Mean of Sample Means (", round(mean_of_sample_means, 4), ") is approximately equal to the Population Mean (", round(pop_mean, 4), ")."))
print(paste("The Standard Deviation of Sample Means (", round(sd_of_sample_means, 4), ") is approximately equal to the Population SD divided by sqrt(n) (", round(theoretical_se, 4), ")."))

